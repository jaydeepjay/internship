function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 Student Portal Application</p>
    </footer>
  );
}

export default Footer;