import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from "react";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import About from "./pages/About";
import Register from "./pages/Register";
import StudentList from "./pages/StudentList";
import Contact from "./pages/Contact";

function App() {
  const [students, setStudents] = useState([]);

  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />

        <Route path="/about" element={<About />} />

        <Route
          path="/register"
          element={
            <Register
              students={students}
              setStudents={setStudents}
            />
          }
        />

        <Route
          path="/students"
          element={<StudentList students={students} />}
        />

        <Route path="/contact" element={<Contact />} />
      </Routes>

      <Footer />
    </BrowserRouter>
  );
}

export default App;