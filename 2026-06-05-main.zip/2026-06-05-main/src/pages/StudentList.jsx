function StudentList({ students }) {
  return (
    <div className="container">
      <h1>Student List</h1>

      <h3>
        Total Registered Students: {students.length}
      </h3>

      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Enrollment</th>
            <th>Branch</th>
            <th>Semester</th>
          </tr>
        </thead>

        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.name}</td>
              <td>{student.enrollment}</td>
              <td>{student.branch}</td>
              <td>{student.semester}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentList;