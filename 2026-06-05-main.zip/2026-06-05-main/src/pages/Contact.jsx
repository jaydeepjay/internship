function Contact() {
  return (
    <div className="container">
      <h1>Contact Us</h1>

      <p>Email: studentportal@gmail.com</p>

      <p>Phone: +91 1234567890</p>
    </div>
  );
}

export default Contact;