function About() {
  return (
    <div className="container">
      <h1>About Us</h1>

      <p>
        Student Portal Application developed using React
        Router DOM and React Components.
      </p>
    </div>
  );
}

export default About;
