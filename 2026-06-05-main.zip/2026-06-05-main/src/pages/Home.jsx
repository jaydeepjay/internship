function Home() {
  return (
    <div className="container">
      <div className="banner">
        <h1>Welcome to Student Portal</h1>
        <p>Manage student registrations easily.</p>
      </div>
    </div>
  );
}

export default Home;