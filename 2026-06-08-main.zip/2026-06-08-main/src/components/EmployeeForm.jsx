import { useState, useEffect } from "react";

function EmployeeForm({ addEmployee, editEmployee }) {
  const [employee, setEmployee] = useState({
    id: "",
    name: "",
    department: "",
    designation: "",
    salary: "",
  });

  useEffect(() => {
    if (editEmployee) {
      setEmployee(editEmployee);
    }
  }, [editEmployee]);

  const handleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (
      !employee.id ||
      !employee.name ||
      !employee.department ||
      !employee.designation ||
      !employee.salary
    ) {
      alert("All fields are required");
      return;
    }

    addEmployee(employee);

    setEmployee({
      id: "",
      name: "",
      department: "",
      designation: "",
      salary: "",
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        name="id"
        placeholder="Employee ID"
        value={employee.id}
        onChange={handleChange}
      />

      <input
        name="name"
        placeholder="Employee Name"
        value={employee.name}
        onChange={handleChange}
      />

      <input
        name="department"
        placeholder="Department"
        value={employee.department}
        onChange={handleChange}
      />

      <input
        name="designation"
        placeholder="Designation"
        value={employee.designation}
        onChange={handleChange}
      />

      <input
        name="salary"
        placeholder="Salary"
        value={employee.salary}
        onChange={handleChange}
      />

      <button type="submit">
        {editEmployee ? "Update" : "Add"}
      </button>
    </form>
  );
}

export default EmployeeForm;