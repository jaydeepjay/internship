function Footer() {
  return (
    <footer>
      <h3>React Employee Management System</h3>
    </footer>
  );
}

export default Footer;
