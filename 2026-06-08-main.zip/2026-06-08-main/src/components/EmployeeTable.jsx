function EmployeeTable({
  employees,
  deleteEmployee,
  setEditEmployee,
}) {
  if (employees.length === 0) {
    return <h2>No Employee Records Found</h2>;
  }

  return (
    <table border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Department</th>
          <th>Designation</th>
          <th>Salary</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody>
        {employees.map((emp) => (
          <tr key={emp.id}>
            <td>{emp.id}</td>
            <td>{emp.name}</td>
            <td>{emp.department}</td>
            <td>{emp.designation}</td>
            <td>{emp.salary}</td>

            <td>
              <button
                onClick={() => setEditEmployee(emp)}
              >
                Edit
              </button>

              <button
                onClick={() => deleteEmployee(emp.id)}
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default EmployeeTable;