import { useState, useEffect } from "react";
import Header from "./components/Header";
import EmployeeForm from "./components/EmployeeForm";
import EmployeeTable from "./components/EmployeeTable";
import Search from "./components/Search";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");
  const [editEmployee, setEditEmployee] = useState(null);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("employees")) || [];
    setEmployees(data);
  }, []);

  useEffect(() => {
    localStorage.setItem("employees", JSON.stringify(employees));
  }, [employees]);

  const addEmployee = (employee) => {
    if (editEmployee) {
      setEmployees(
        employees.map((emp) =>
          emp.id === employee.id ? employee : emp
        )
      );
      setEditEmployee(null);
    } else {
      setEmployees([...employees, employee]);
    }
  };

  const deleteEmployee = (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete?"
    );

    if (confirmDelete) {
      setEmployees(employees.filter((emp) => emp.id !== id));
    }
  };

  const filteredEmployees = employees.filter(
    (emp) =>
      emp.name.toLowerCase().includes(search.toLowerCase()) ||
      emp.id.includes(search)
  );

  return (
    <>
      <Header />

      <Search search={search} setSearch={setSearch} />

      <EmployeeForm
        addEmployee={addEmployee}
        editEmployee={editEmployee}
      />

      <h3>Total Employees : {employees.length}</h3>

      <EmployeeTable
        employees={filteredEmployees}
        deleteEmployee={deleteEmployee}
        setEditEmployee={setEditEmployee}
      />

      <Footer />
    </>
  );
}

export default App;