import { useState } from "react";
import Header from "./components/Header";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [tasks, setTasks] = useState([]);

  const addTask = (text) => {
    const newTask = {
      id: Date.now(),
      text,
      completed: false,
      date: new Date().toLocaleString(),
    };

    setTasks([...tasks, newTask]);
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const toggleComplete = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id
          ? {
              ...task,
              completed: !task.completed,
            }
          : task
      )
    );
  };

  const editTask = (id) => {
    const updatedText = prompt("Edit Task");

    if (!updatedText) return;

    setTasks(
      tasks.map((task) =>
        task.id === id
          ? { ...task, text: updatedText }
          : task
      )
    );
  };

  const clearAllTasks = () => {
    setTasks([]);
  };

  const completedTasks =
    tasks.filter((task) => task.completed).length;

  const pendingTasks =
    tasks.filter((task) => !task.completed).length;

  return (
    <>
      <Header />

      <TaskForm addTask={addTask} />

      <button onClick={clearAllTasks}>
        Clear All Tasks
      </button>

      <TaskList
        tasks={tasks}
        deleteTask={deleteTask}
        toggleComplete={toggleComplete}
        editTask={editTask}
      />

      <Footer
        total={tasks.length}
        completed={completedTasks}
        pending={pendingTasks}
      />
    </>
  );
}

export default App;