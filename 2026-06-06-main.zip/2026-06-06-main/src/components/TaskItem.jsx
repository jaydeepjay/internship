function TaskItem({
  task,
  deleteTask,
  toggleComplete,
  editTask,
}) {
  return (
    <li className={task.completed ? "completed" : ""}>
      <h3>{task.text}</h3>

      <p>
        {task.completed ? "✅ Completed" : "⏳ Pending"}
      </p>

      <small>{task.date}</small>

      <br />

      <button
        onClick={() => toggleComplete(task.id)}
      >
        Complete
      </button>

      <button
        onClick={() => editTask(task.id)}
      >
        Edit
      </button>

      <button
        onClick={() => deleteTask(task.id)}
      >
        Delete
      </button>
    </li>
  );
}

export default TaskItem;