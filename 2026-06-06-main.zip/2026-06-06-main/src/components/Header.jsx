function Header() {
  return (
    <header className="header">
      <h1>React Todo List App</h1>
    </header>
  );
}

export default Header;