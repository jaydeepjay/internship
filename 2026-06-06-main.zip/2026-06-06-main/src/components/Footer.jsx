function Footer({
  total,
  completed,
  pending,
}) {
  return (
    <footer>
      <h3>Total Tasks : {total}</h3>
      <h3>Completed : {completed}</h3>
      <h3>Pending : {pending}</h3>
    </footer>
  );
}

export default Footer;