import React, { useState } from "react";

export default function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [error, setError] = useState({});

  // Handle Input Change
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Validation Method
  const validate = () => {
    let err = {};

    if (!form.email) err.email = "Email is required";
    if (!form.password) err.password = "Password is required";

    return err;
  };

  // Submit Method
  const handleSubmit = (e) => {
    e.preventDefault();

    const err = validate();
    setError(err);

    if (Object.keys(err).length === 0) {
      console.log("LOGIN DATA:", form);
      alert("Login Successful");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>

      <input
        type="email"
        name="email"
        placeholder="Enter Email"
        onChange={handleChange}
      />
      <p className="error">{error.email}</p>

      <input
        type="password"
        name="password"
        placeholder="Enter Password"
        onChange={handleChange}
      />
      <p className="error">{error.password}</p>

      <button type="submit">Login</button>
    </form>
  );
}