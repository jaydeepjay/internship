import React, { useState } from "react";

export default function Register() {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    mobile: "",
    password: "",
    confirmPassword: "",
  });

  const [error, setError] = useState({});

  // Handle Input Change
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Validation Method
  const validate = () => {
    let err = {};

    if (!form.fullName) err.fullName = "Full Name is required";
    if (!form.email) err.email = "Email is required";
    if (!form.mobile) err.mobile = "Mobile Number is required";
    if (!form.password) err.password = "Password is required";

    if (!form.confirmPassword)
      err.confirmPassword = "Confirm Password is required";
    else if (form.password !== form.confirmPassword)
      err.confirmPassword = "Passwords do not match";

    return err;
  };

  // Submit Method
  const handleSubmit = (e) => {
    e.preventDefault();

    const err = validate();
    setError(err);

    if (Object.keys(err).length === 0) {
      console.log("REGISTER DATA:", form);
      alert("Registration Successful");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Register</h2>

      <input
        type="text"
        name="fullName"
        placeholder="Full Name"
        onChange={handleChange}
      />
      <p className="error">{error.fullName}</p>

      <input
        type="email"
        name="email"
        placeholder="Email"
        onChange={handleChange}
      />
      <p className="error">{error.email}</p>

      <input
        type="text"
        name="mobile"
        placeholder="Mobile Number"
        onChange={handleChange}
      />
      <p className="error">{error.mobile}</p>

      <input
        type="password"
        name="password"
        placeholder="Password"
        onChange={handleChange}
      />
      <p className="error">{error.password}</p>

      <input
        type="password"
        name="confirmPassword"
        placeholder="Confirm Password"
        onChange={handleChange}
      />
      <p className="error">{error.confirmPassword}</p>

      <button type="submit">Register</button>
    </form>
  );
}