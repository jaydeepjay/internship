import React, { useState } from "react";
import Login from "./components/Login";
import Register from "./components/Register";
import "./styles.css";

export default function App() {
  const [page, setPage] = useState("login");

  return (
    <div className="container">
      <div className="card">

        {/* Navigation Buttons */}
        <div className="toggle">
          <button onClick={() => setPage("login")}>Login</button>
          <button onClick={() => setPage("register")}>Register</button>
        </div>

        {/* Conditional Rendering */}
        {page === "login" ? <Login /> : <Register />}

      </div>
    </div>
  );
}